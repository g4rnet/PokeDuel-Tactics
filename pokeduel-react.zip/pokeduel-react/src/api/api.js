// ==========================================================
// api.js — тонкий клієнт PokeAPI (https://pokeapi.co/api/v2)
// Усі дані гри (покемони, ходи, типи) беруться звідси.
// ==========================================================

const BASE_URL = 'https://pokeapi.co/api/v2';

// Кеш промісів: один і той самий запит ніколи не йде в мережу двічі
const cache = new Map();

/** GET-запит із кешем і однією повторною спробою. */
function getJSON(path) {
  if (!cache.has(path)) {
    const request = (async () => {
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          const response = await fetch(`${BASE_URL}${path}`);
          if (!response.ok) throw new Error(`PokeAPI ${response.status}: ${path}`);
          return await response.json();
        } catch (error) {
          if (attempt === 2) throw error;
        }
      }
    })();
    // Невдалий запит прибираємо з кешу, щоб його можна було повторити
    request.catch(() => cache.delete(path));
    cache.set(path, request);
  }
  return cache.get(path);
}

/** /pokemon/{id|name}: статі, типи, спрайти, список ходів. */
export const fetchPokemon = (idOrName) => getJSON(`/pokemon/${idOrName}`);

/** /move/{name}: сила, точність, PP, тип, клас шкоди. */
export const fetchMove = (name) => getJSON(`/move/${name}`);

/** /type/{name}: damage_relations (подвійна / половинна / нульова шкода). */
export const fetchType = (name) => getJSON(`/type/${name}`);

/** Діапазон id покемонів 1 покоління, з якого обираються вороги. */
export const POKEMON_POOL = { min: 1, max: 151 };
