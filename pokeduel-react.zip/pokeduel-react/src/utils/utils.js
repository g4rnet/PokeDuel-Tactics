// ==========================================================
// utils.js — вспомогательные функции и замыкания (Задание 1)
// ==========================================================

/** Случайное целое число в диапазоне [min, max]. */
export const random = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

/** Возвращает true с вероятностью p (p от 0 до 1). */
export const chance = (p) => Math.random() < p;

/** Промис-пауза: удобно для таймаутов ходов ИИ и анимаций (async/await). */
export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Выбирает n случайных разных элементов из массива. */
export const pickRandom = (array, n) => {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = random(0, i);
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy.slice(0, n);
};

/**
 * ЗАМЫКАНИЕ №1: счётчик кликов по кнопкам игры.
 * Переменные total и perButton видны только внутри функции,
 * снаружи с ними можно работать лишь через возвращаемые методы.
 * @returns {{track: function(string): number, getTotal: function(): number, getCount: function(string): number}}
 */
export function createClickTracker() {
  let total = 0;                 // общее число кликов (приватное состояние)
  const perButton = new Map();   // клики по каждой кнопке отдельно

  return {
    track(label) {
      total++;
      perButton.set(label, (perButton.get(label) || 0) + 1);
      console.log(
        `[Клик #${total}] Кнопка "${label}" — нажатий на неё: ${perButton.get(label)}. Всего кликов: ${total}`
      );
      return total;
    },
    getTotal: () => total,
    getCount: (label) => perButton.get(label) || 0,
  };
}

/**
 * ЗАМЫКАНИЕ №2: лимит использований одной кнопки (атаки) за бой.
 * Каждый вызов создаёт НОВОЕ изолированное состояние (used, limit),
 * поэтому у каждой атаки свой независимый счётчик.
 * @param {number} initialLimit максимум применений за бой (может быть Infinity)
 */
export function createUsageLimiter(initialLimit) {
  let limit = initialLimit;
  let used = 0;

  return {
    /** Пытается потратить одно использование. false — лимит исчерпан. */
    tryUse() {
      if (used >= limit) return false;
      used++;
      return true;
    },
    left: () => Math.max(0, limit - used),
    isExhausted: () => used >= limit,
    increaseLimit(amount) { limit += amount; },
    /** Новый бой — счётчик использований обнуляется. */
    reset() { used = 0; },
  };
}
