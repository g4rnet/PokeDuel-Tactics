// ==========================================================
// Pokemon.js — универсальный класс бойца (герой и враги)
// ==========================================================
import { chance, random, sleep } from "../utils/utils.js";
import { Attack } from "./Attack.js";
import { getTypeMultiplier } from "./typeChart.js";
import { t, typeName } from "../i18n/i18n.js";

export const MAX_CHARGE = 100; // полная шкала ульты
export const CRIT_MULTIPLIER = 1.5; // множитель крита

// Периодический урон: доля от макс. HP за ход и длительность в ходах
export const STATUS_INFO = {
  poison: { icon: "☠️", get label() { return t("status.poison"); }, rate: 0.06, turns: 4 },
  burn: { icon: "🔥", get label() { return t("status.burn"); }, rate: 0.05, turns: 3 },
};

export const AURAS = {
  "fire-coat": {
    icon: "🔥",
    get name() { return t("aura.fire-coat.name"); },
    get desc() { return t("aura.fire-coat.desc"); },
  },
  "thick-hide": {
    icon: "🪨",
    get name() { return t("aura.thick-hide.name"); },
    get desc() { return t("aura.thick-hide.desc"); },
  },
};

const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

export class Pokemon {
  constructor({
    name,
    types,
    level = 1,
    maxHP = 100,
    spriteUrl,
    stats,
    attacks,
    root,
    damageMultiplier = 1,
    aura = null,
    isBoss = false,
  }) {
    this.name = name;
    this.types = types;
    this.stats = stats;
    this.level = level;
    this.maxHP = maxHP;
    this.hp = maxHP;
    this.attacks = attacks;
    this.aura = aura; // 'fire-coat' | 'thick-hide' | null
    this.isBoss = isBoss;
    this.phase = 1;

    // Бонусы (меняются усилениями, талантами, предметами)
    this.damageMultiplier = damageMultiplier;
    this.critBonus = 0;
    this.critDamageBonus = 0; // талант Offense: +% к силе крита
    this.accuracyBonus = 0;
    this.lowAccuracyBonus = 0; // талант Offense 3: бонус для мувов с точностью < 85
    this.vampirism = 0;
    this.startCharge = 0;
    this.charge = 0;
    this.isGuarding = false;
    this.perfectGuardArmed = false;
    this.dotReduction = 0; // талант Survival 2: 0.5 = на 50% меньше урона от статусов

    // Предметы и таланты (включаются из game.js)
    this.firstMoveBonus = 0; // Choice Scarf: +0.25
    this.firstMovePPCost = 1; // Choice Scarf: 2
    this.restorePPOnSuper = false; // талант Offense 2
    this.innatePoison = 0; // пассивка стартовика (Gastly)
    this.physicalBonus = 0; // пассивка стартовика (Heracross)

    // Карты-синергии: id -> true
    this.flags = {};
    this.passives = []; // выбранные карты (для иконок и кодекса)

    // Состояние боя
    this.statuses = {}; // { poison: ходов_осталось, burn: ... }
    this.lastMoveType = null;
    this.firstMoveUsed = false;
    this.superUsed = false;

    // Запасная атака, если все остальные недоступны
    this.struggle = new Attack({
      name: t("struggle"),
      minDamage: 3,
      maxDamage: 5,
      maxPP: Infinity,
      type: "normal",
      maxUses: Infinity,
      accuracy: 100,
      critChance: 0,
      chargeGain: 0,
    });

    // Кэш DOM-элементов карточки
    this.dom = {
      root,
      lvl: root.querySelector(".lvl"),
      sprite: root.querySelector(".sprite"),
      name: root.querySelector(".name"),
      hp: root.querySelector(".hp .text"),
      bar: root.querySelector(".health"),
      charge: root.querySelector(".charge-fill"),
      typeTag: root.querySelector(".type-tag"),
      auraTag: root.querySelector(".aura-tag"),
      statusTag: root.querySelector(".status-tag"),
      passives: root.querySelector(".passives"),
    };

    this.dom.root.classList.remove("fainted", "hit-animation", "miss-animation");
    this.dom.sprite.src = spriteUrl;
    this.dom.sprite.alt = name;
    this.dom.name.textContent = isBoss ? `👑 ${name}` : name;
    if (this.dom.typeTag) this.dom.typeTag.textContent = types.map(typeName).join(" / ");
    if (this.dom.auraTag) {
      const a = AURAS[aura];
      this.dom.auraTag.textContent = a ? `${a.icon} ${a.name}` : "";
      this.dom.auraTag.title = a ? a.desc : "";
    }
    this.render();
  }

  get isFainted() {
    return this.hp <= 0;
  }

  // ---------- Отрисовка ----------
  render() {
    this.renderLevel();
    this.renderHP();
    this.renderCharge();
    this.renderStatuses();
    this.renderPassives();
  }

  renderLevel() {
    this.dom.lvl.textContent = t("hud.lvl", { n: this.level });
  }

  renderHP() {
    this.dom.hp.textContent = `${this.hp} / ${this.maxHP}`;
    const percent = (this.hp / this.maxHP) * 100;
    this.dom.bar.style.width = `${percent}%`;
    this.dom.bar.classList.remove("low", "critical");
    if (percent < 20) this.dom.bar.classList.add("critical");
    else if (percent < 60) this.dom.bar.classList.add("low");
  }

  renderCharge() {
    if (!this.dom.charge) return;
    this.dom.charge.style.width = `${(this.charge / MAX_CHARGE) * 100}%`;
    this.dom.charge.classList.toggle("ready", this.charge >= MAX_CHARGE);
  }

  renderStatuses() {
    if (!this.dom.statusTag) return;
    this.dom.statusTag.textContent = Object.entries(this.statuses)
      .map(([k, turns]) => `${STATUS_INFO[k].icon} ${STATUS_INFO[k].label} (${turns})`)
      .join("  ");
  }

  /** Иконки активных карт под шкалой HP. */
  renderPassives() {
    if (!this.dom.passives) return;
    this.dom.passives.innerHTML = "";
    this.passives.forEach((card) => {
      const el = document.createElement("span");
      el.className = "passive-icon";
      el.textContent = card.icon;
      el.title = `${card.title}: ${typeof card.desc === "function" ? card.desc(this) : card.desc}`;
      this.dom.passives.appendChild(el);
    });
  }

  // ---------- Состояние ----------
  /** Получение урона + анимация удара (асинхронно). Возвращает true, если покемон погиб. */
  async takeDamage(amount) {
    this.hp = Math.max(0, this.hp - amount);
    this.renderHP();
    this.dom.root.classList.add("hit-animation");
    if (this.isFainted) this.dom.root.classList.add("fainted");
    await sleep(350);
    this.dom.root.classList.remove("hit-animation");
    return this.isFainted;
  }

  /** Анимация промаха защитника (уклонение). */
  async dodge() {
    this.dom.root.classList.add("miss-animation");
    await sleep(350);
    this.dom.root.classList.remove("miss-animation");
  }

  heal(amount) {
    this.hp = Math.min(this.maxHP, this.hp + amount);
    this.renderHP();
  }

  increaseMaxHP(amount) {
    this.maxHP += amount;
    this.heal(amount);
  }

  levelUp() {
    this.level++;
    this.renderLevel();
  }

  addCharge(amount) {
    this.charge = Math.min(MAX_CHARGE, this.charge + amount);
    this.renderCharge();
  }

  hasCard(id) {
    return Boolean(this.flags[id]);
  }

  addPassive(card) {
    this.passives.push(card);
    this.renderPassives();
  }

  // ---------- Статусы ----------
  applyStatus(name) {
    this.statuses[name] = STATUS_INFO[name].turns; // повторное наложение обновляет длительность
    this.renderStatuses();
  }

  clearStatuses() {
    this.statuses = {};
    this.renderStatuses();
  }

  /**
   * Конец хода владельца: периодический урон от статусов.
   * @returns {Promise<{damage:number, names:string[]}>}
   */
  async tickStatuses() {
    const names = Object.keys(this.statuses);
    if (names.length === 0) return { damage: 0, names };
    let total = 0;
    names.forEach((name) => {
      total += Math.max(1, Math.round(this.maxHP * STATUS_INFO[name].rate * (1 - this.dotReduction)));
      this.statuses[name]--;
      if (this.statuses[name] <= 0) delete this.statuses[name];
    });
    this.renderStatuses();
    await this.takeDamage(total);
    return { damage: total, names };
  }

  /** Подготовка к новому бою: PP, кулдауны, лимиты и шкала. HP сохраняется. */
  resetForBattle() {
    this.attacks.forEach((a) => a.resetForBattle());
    this.charge = this.startCharge;
    this.isGuarding = false;
    this.perfectGuardArmed = false;
    this.statuses = {};
    this.lastMoveType = null;
    this.firstMoveUsed = false;
    this.superUsed = false;
    this.dom.root.classList.remove("fainted", "hit-animation", "miss-animation");
    this.render();
  }

  /** Полный сброс (новый забег). */
  reset() {
    this.hp = this.maxHP;
    this.resetForBattle();
  }

  // ---------- Атаки ----------
  /** Ульту можно применить только при полной шкале. */
  canUse(attack) {
    return attack.isAvailable() && (!attack.isUlt || this.charge >= MAX_CHARGE);
  }

  getAvailableAttacks() {
    return this.attacks.filter((a) => this.canUse(a));
  }

  tickCooldowns() {
    this.attacks.forEach((a) => a.tickCooldown());
  }

  /** Итоговая точность мува: база + бонусы (талант для < 85% тоже учитывается). */
  getEffectiveAccuracy(attack) {
    const lowBonus = attack.accuracy < 85 ? this.lowAccuracyBonus : 0;
    return clamp(attack.accuracy + this.accuracyBonus + lowBonus, 1, 100);
  }

  /**
   * Атака по цели: точность → тип → статы → крит → карты → урон → эффекты.
   * @returns {Promise<object>} результат для вывода в лог
   */
  async useAttack(attack, defender) {
    const isLastPP = attack.currentPP === 1; // для Desperate Power
    const prevType = this.lastMoveType;
    const useScarf = this.firstMoveBonus > 0 && !this.firstMoveUsed;

    attack.use(useScarf ? this.firstMovePPCost : 1);
    this.firstMoveUsed = true;
    this.lastMoveType = attack.type;
    if (attack.isUlt) this.charge = 0; // ульта сбрасывает шкалу
    this.renderCharge();

    const result = {
      attacker: this,
      defender,
      attack,
      missed: false,
      crit: false,
      effectiveness: 1,
      damage: 0,
      notes: [], // дополнительные строки для лога
    };

    // 1. Точность
    const accuracy = this.getEffectiveAccuracy(attack);
    result.accuracy = accuracy;
    if (!chance(accuracy / 100)) {
      result.missed = true;
      await defender.dodge();
      return result;
    }

    // 2. Тип: множитель из PokeAPI (0 = иммунитет, 4 = двойное преимущество)
    result.effectiveness = getTypeMultiplier(attack.type, defender.types);
    if (result.effectiveness === 0) {
      await defender.dodge();
      return result;
    }

    // 3. Урон: разброс × стат атаки/защиты × тип × крит × бонусы × карты
    const [atkKey, defKey] =
      attack.damageClass === "special"
        ? ["specialAttack", "specialDefense"]
        : ["attack", "defense"];
    const statRatio = clamp(this.stats[atkKey] / defender.stats[defKey], 0.7, 1.4);
    const base = random(attack.minDamage, attack.maxDamage);

    // Крит: Overload гарантирует крит (Electric после Water); Thick Hide крит блокирует
    const overload = this.flags.overload && attack.type === "electric" && prevType === "water";
    let crit = overload || chance((attack.critChance + this.critBonus) / 100);
    if (crit && defender.aura === "thick-hide") {
      crit = false;
      result.notes.push(t("note.thickHide"));
    } else if (overload) {
      result.notes.push(t("note.overload"));
    }
    result.crit = crit;

    let finalDamage =
      base *
      statRatio *
      result.effectiveness *
      (crit ? CRIT_MULTIPLIER * (1 + this.critDamageBonus) : 1) *
      this.damageMultiplier;

    if (this.flags.desperate && isLastPP) {
      finalDamage *= 1.5;
      result.notes.push(t("note.desperate"));
    }
    if (this.flags.shatter && (attack.type === "rock" || attack.type === "ground")) {
      if (defender.isGuarding) {
        finalDamage *= 1.4;
        result.notes.push(t("note.shatter"));
      } else {
        finalDamage *= 0.9;
      }
    }
    if (useScarf) {
      finalDamage *= 1 + this.firstMoveBonus;
      result.notes.push(t("note.scarf"));
    }
    if (this.physicalBonus && attack.damageClass === "physical") {
      finalDamage *= 1 + this.physicalBonus;
    }

    // Защита снижает следующий полученный удар и затем заканчивается.
    let reflected = 0;
    if (defender.isGuarding) {
      if (defender.perfectGuardArmed) {
        reflected = Math.round(finalDamage * 0.25); // Perfect Guard: 25% от удара до снижения
      }
      finalDamage *= 0.45;
      defender.isGuarding = false;
      defender.perfectGuardArmed = false;
      result.guarded = true;
    }
    result.damage = Math.max(1, Math.round(finalDamage));

    // 4. Заряд ульты и талант Offense 2 (1 PP за первый супер-эффективный удар)
    this.addCharge(attack.chargeGain);
    if (this.restorePPOnSuper && result.effectiveness > 1 && !this.superUsed) {
      this.superUsed = true;
      if (attack.currentPP < attack.maxPP) {
        attack.currentPP++;
        result.notes.push(t("note.talentPP", { m: attack.name }));
      }
    }

    await defender.takeDamage(result.damage);

    // 5. Эффекты после попадания
    if (this.vampirism > 0) {
      const healed = Math.round(result.damage * this.vampirism);
      if (healed > 0) this.heal(healed);
    }

    const poisonChance = Math.max(
      this.flags.venom && attack.damageClass === "physical" ? 0.2 : 0,
      this.innatePoison,
    );
    if (poisonChance > 0 && !defender.isFainted && chance(poisonChance)) {
      defender.applyStatus("poison");
      result.notes.push(t("note.poisoned", { d: defender.name }));
    }

    if (defender.aura === "fire-coat" && attack.damageClass === "physical") {
      this.applyStatus("burn");
      result.notes.push(t("note.burned", { a: this.name }));
    }

    if (reflected > 0) {
      result.notes.push(t("note.reflect", { n: reflected }));
      await this.takeDamage(reflected);
    }
    return result;
  }
}
