// ==========================================================
// PokeDuel server — accounts, cloud save, leaderboard
// Express + SQLite (better-sqlite3). No other dependencies:
// passwords are hashed with scrypt from node:crypto.
// ==========================================================
import express from "express";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3001;
const DB_FILE = process.env.DB_FILE || path.join(__dirname, "pokeduel.db");
const DIST_DIR = process.env.DIST_DIR || path.join(__dirname, "..", "dist");
const SESSION_DAYS = 60;

// Must match STARTERS in src/game/meta.js
const STARTERS = ["pikachu", "charmander", "bulbasaur", "squirtle", "gastly", "heracross"];
const MAX_WAVE = 500; // sanity limit

// ---------- DB ----------
const db = new Database(DB_FILE);
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nick TEXT NOT NULL,
    nick_key TEXT NOT NULL UNIQUE,
    salt TEXT NOT NULL,
    hash TEXT NOT NULL,
    meta TEXT,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    starter TEXT NOT NULL,
    wave INTEGER NOT NULL,
    kills INTEGER NOT NULL,
    clicks INTEGER NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_runs_wave ON runs(wave DESC, created_at ASC);
  CREATE INDEX IF NOT EXISTS idx_runs_user ON runs(user_id);
`);

const q = {
  userByNick: db.prepare("SELECT * FROM users WHERE nick_key = ?"),
  insertUser: db.prepare("INSERT INTO users (nick, nick_key, salt, hash, meta, created_at) VALUES (?, ?, ?, ?, ?, ?)"),
  insertSession: db.prepare("INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)"),
  sessionUser: db.prepare(
    `SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires_at > ?`
  ),
  deleteSession: db.prepare("DELETE FROM sessions WHERE token_hash = ?"),
  purgeSessions: db.prepare("DELETE FROM sessions WHERE expires_at <= ?"),
  saveMeta: db.prepare("UPDATE users SET meta = ? WHERE id = ?"),
  insertRun: db.prepare(
    "INSERT INTO runs (user_id, starter, wave, kills, clicks, created_at) VALUES (?, ?, ?, ?, ?, ?)"
  ),
  // One row per player: their best run (highest wave; ties -> more kills, then earlier)
  leaderboard: db.prepare(
    `SELECT nick, starter, wave, kills, created_at FROM (
       SELECT u.nick, r.starter, r.wave, r.kills, r.created_at,
              ROW_NUMBER() OVER (
                PARTITION BY r.user_id
                ORDER BY r.wave DESC, r.kills DESC, r.created_at ASC
              ) AS rn
       FROM runs r JOIN users u ON u.id = r.user_id
       WHERE (@starter IS NULL OR r.starter = @starter)
     ) WHERE rn = 1
     ORDER BY wave DESC, kills DESC, created_at ASC
     LIMIT @limit`
  ),
};

// ---------- helpers ----------
const sha256 = (s) => crypto.createHash("sha256").update(s).digest("hex");
const now = () => Date.now();
// SQLite NOCASE only folds ASCII, so Cyrillic nicks are compared by a lowercase key
const nickKey = (n) => n.toLocaleLowerCase("en-US");

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}

function verifyPassword(password, salt, hash) {
  const a = Buffer.from(hashPassword(password, salt), "hex");
  const b = Buffer.from(hash, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function createSession(userId) {
  const token = crypto.randomBytes(32).toString("hex");
  q.insertSession.run(sha256(token), userId, now() + SESSION_DAYS * 86400_000);
  return token;
}

// Nick: 3-20 chars, letters (incl. Ukrainian/Cyrillic), digits, _ and -
const NICK_RE = /^[\p{L}\p{N}_-]{3,20}$/u;

// Very small in-memory rate limiter (per IP + route group)
const hits = new Map();
function rateLimit(name, max, windowMs) {
  return (req, res, next) => {
    const key = `${name}:${req.ip}`;
    const t = now();
    const arr = (hits.get(key) || []).filter((x) => t - x < windowMs);
    if (arr.length >= max) return res.status(429).json({ error: "too_many_requests" });
    arr.push(t);
    hits.set(key, arr);
    next();
  };
}
setInterval(() => {
  const t = now();
  for (const [k, arr] of hits) if (!arr.some((x) => t - x < 3600_000)) hits.delete(k);
  q.purgeSessions.run(t);
}, 600_000).unref();

function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : "";
  if (!token) return res.status(401).json({ error: "unauthorized" });
  const user = q.sessionUser.get(sha256(token), now());
  if (!user) return res.status(401).json({ error: "unauthorized" });
  req.user = user;
  req.tokenHash = sha256(token);
  next();
}

const safeJson = (s) => {
  try { return s ? JSON.parse(s) : null; } catch { return null; }
};

// Clamp the cloud-save to a sane shape so nobody stores garbage / huge blobs
function sanitizeMeta(m) {
  if (!m || typeof m !== "object") return null;
  const int = (v, max) => Math.max(0, Math.min(max, Number.isFinite(+v) ? Math.floor(+v) : 0));
  const list = (v, allowed) => (Array.isArray(v) ? [...new Set(v.filter((x) => allowed.includes(x)))] : []);
  const talents = m.unlockedTalents || {};
  const selected = STARTERS.includes(m.selectedStarter) ? m.selectedStarter : "pikachu";
  const items = ["leftovers", "scarf", "sash", "expshare"];
  const unlockedStarters = list(m.unlockedStarters, STARTERS);
  if (!unlockedStarters.includes("pikachu")) unlockedStarters.unshift("pikachu");
  return {
    bp: int(m.bp, 1_000_000),
    unlockedStarters,
    selectedStarter: unlockedStarters.includes(selected) ? selected : "pikachu",
    unlockedItems: list(m.unlockedItems, items),
    equippedItem: items.includes(m.equippedItem) ? m.equippedItem : null,
    unlockedTalents: {
      offense: int(talents.offense, 3),
      survival: int(talents.survival, 3),
      tactics: int(talents.tactics, 3),
    },
  };
}

// ---------- app ----------
const app = express();
app.set("trust proxy", 1); // behind nginx / a hosting proxy
app.use(express.json({ limit: "20kb" }));

const authLimiter = rateLimit("auth", 20, 10 * 60_000);

app.post("/api/register", authLimiter, (req, res) => {
  const nick = String(req.body?.nick ?? "").trim();
  const password = String(req.body?.password ?? "");
  if (!NICK_RE.test(nick)) return res.status(400).json({ error: "bad_nick" });
  if (password.length < 6 || password.length > 100) return res.status(400).json({ error: "bad_password" });
  if (q.userByNick.get(nickKey(nick))) return res.status(409).json({ error: "nick_taken" });

  const salt = crypto.randomBytes(16).toString("hex");
  const meta = sanitizeMeta(req.body?.meta); // progress made as a guest is carried over
  let info;
  try {
    info = q.insertUser.run(nick, nickKey(nick), salt, hashPassword(password, salt), meta ? JSON.stringify(meta) : null, now());
  } catch {
    return res.status(409).json({ error: "nick_taken" });
  }
  const token = createSession(info.lastInsertRowid);
  res.json({ token, nick, meta });
});

app.post("/api/login", authLimiter, (req, res) => {
  const nick = String(req.body?.nick ?? "").trim();
  const password = String(req.body?.password ?? "");
  const user = q.userByNick.get(nickKey(nick));
  // same error for "no such user" and "wrong password"
  if (!user || !verifyPassword(password, user.salt, user.hash)) {
    return res.status(401).json({ error: "bad_credentials" });
  }
  const token = createSession(user.id);
  res.json({ token, nick: user.nick, meta: safeJson(user.meta) });
});

app.post("/api/logout", auth, (req, res) => {
  q.deleteSession.run(req.tokenHash);
  res.json({ ok: true });
});

app.get("/api/me", auth, (req, res) => {
  res.json({ nick: req.user.nick, meta: safeJson(req.user.meta) });
});

app.put("/api/meta", auth, rateLimit("meta", 120, 60_000), (req, res) => {
  const meta = sanitizeMeta(req.body?.meta);
  if (!meta) return res.status(400).json({ error: "bad_meta" });
  q.saveMeta.run(JSON.stringify(meta), req.user.id);
  res.json({ ok: true });
});

app.post("/api/runs", auth, rateLimit("runs", 60, 60_000), (req, res) => {
  const { starter, wave, kills, clicks } = req.body || {};
  const w = Math.floor(+wave), k = Math.floor(+kills), c = Math.floor(+clicks) || 0;
  if (!STARTERS.includes(starter)) return res.status(400).json({ error: "bad_starter" });
  if (!(w >= 1 && w <= MAX_WAVE) || !(k >= 0 && k <= w) || c < 0 || c > 1_000_000) {
    return res.status(400).json({ error: "bad_run" });
  }
  q.insertRun.run(req.user.id, starter, w, k, c, now());
  res.json({ ok: true });
});

app.get("/api/leaderboard", rateLimit("lb", 120, 60_000), (req, res) => {
  const limit = Math.max(1, Math.min(100, parseInt(req.query.limit) || 50));
  const starter = STARTERS.includes(req.query.starter) ? req.query.starter : null;
  res.json({ rows: q.leaderboard.all({ starter, limit }) });
});

// ---------- serve the built game (npm run build -> dist/) ----------
if (fs.existsSync(DIST_DIR)) {
  app.use(express.static(DIST_DIR));
  app.get(/^\/(?!api\/).*/, (_req, res) => res.sendFile(path.join(DIST_DIR, "index.html")));
}

app.listen(PORT, () => console.log(`PokeDuel server on http://localhost:${PORT}`));
