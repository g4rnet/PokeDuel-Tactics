// ==========================================================
// Attack.js — класс атаки (данные приходят из PokeAPI /move)
// ==========================================================
import { createUsageLimiter } from '../utils/utils.js';

export class Attack {
  /**
   * @param {object} o
   * @param {string} o.name
   * @param {number} o.minDamage
   * @param {number} o.maxDamage
   * @param {number} [o.maxPP=99]          запас PP
   * @param {number} [o.cooldownTurns=0]   кулдаун в ходах
   * @param {string} [o.type='normal']     тип атаки (из API)
   * @param {string} [o.damageClass='physical'] physical | special
   * @param {number} [o.accuracy=100]      точность, % (шанс попасть)
   * @param {number} [o.critChance=10]     шанс крита, %
   * @param {number} [o.maxUses=6]         лимит применений за бой (замыкание)
   * @param {number} [o.chargeGain=15]     сколько энергии даёт успешный удар
   * @param {boolean} [o.isUlt=false]      суперудар (нужна полная шкала)
   */
  constructor({
    name, minDamage, maxDamage, maxPP = 99, cooldownTurns = 0, type = 'normal', damageClass = 'physical',
    accuracy = 100, critChance = 10, maxUses = 6, chargeGain = 15, isUlt = false,
  }) {
    this.name = name;
    this.minDamage = minDamage;
    this.maxDamage = maxDamage;
    this.maxPP = maxPP;
    this.currentPP = maxPP;
    this.cooldownTurns = cooldownTurns;
    this.currentCD = 0;
    this.type = type;
    this.damageClass = damageClass; // physical | special — какой стат участвует в уроне
    this.accuracy = accuracy;
    this.critChance = critChance;
    this.chargeGain = chargeGain;
    this.isUlt = isUlt;
    this.justUsed = false; // чтобы кулдаун не «съедался» в том же ходу
    this.limiter = createUsageLimiter(maxUses); // изолированный счётчик этой кнопки
  }

  get usesLeft() { return this.limiter.left(); }

  /** Атаку можно применить: есть PP, нет кулдауна, лимит не исчерпан. */
  isAvailable() {
    return this.currentPP > 0 && this.currentCD === 0 && !this.limiter.isExhausted();
  }

  /** Применение: тратит PP (по умолчанию 1) и одно использование, ставит кулдаун. */
  use(ppCost = 1) {
    if (!this.limiter.tryUse()) return false;
    this.currentPP = Math.max(0, this.currentPP - ppCost);
    this.currentCD = this.cooldownTurns;
    this.justUsed = this.cooldownTurns > 0;
    return true;
  }

  /** Вызывается в конце хода владельца. */
  tickCooldown() {
    if (this.justUsed) { this.justUsed = false; return; }
    if (this.currentCD > 0) this.currentCD--;
  }

  increaseMaxUses(amount) { this.limiter.increaseLimit(amount); }

  /** Сброс перед новым боем (PP, кулдаун, лимит нажатий). */
  resetForBattle() {
    this.currentPP = this.maxPP;
    this.currentCD = 0;
    this.justUsed = false;
    this.limiter.reset();
  }
}
