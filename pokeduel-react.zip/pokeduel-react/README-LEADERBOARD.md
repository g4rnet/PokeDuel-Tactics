# Аккаунты и таблица лидеров для PokeDuel

## Что добавлено
**Сервер** (`server/`, Node + Express + SQLite):
- `POST /api/register`, `POST /api/login`, `POST /api/logout`, `GET /api/me`
- `PUT /api/meta` — облачное сохранение BP / стартовиков / предметов / талантов
- `POST /api/runs` — результат забега (покемон, волна, победы, клики)
- `GET /api/leaderboard?starter=pikachu` — лучший забег каждого игрока (фильтр по покемону)

**Клиент** (`src/`):
- `api/server.js` — обёртка над API, токен в localStorage
- `auth/AuthScreen.jsx` — вход / регистрация / «играть как гость»
- `auth/Leaderboard.jsx` — таблица лидеров с фильтром по покемону
- `App.jsx` — `Root` (проверка сессии), кнопки 🏅 / ник / выход, отправка забега и синхронизация меты
- `game/game.js` — в `onRunEnd` теперь приходит `starter` (покемон, с которым начат забег)
- `game/meta.js` — `clearLocalMeta()`
- `i18n/i18n.js` — тексты UA/EN, `css/style-cards.css` — стили

## Запуск локально
```bash
# терминал 1 — сервер
cd server && npm install && npm start        # http://localhost:3001

# терминал 2 — игра (Vite)
npm run dev
```
В `vite.config.js` добавьте прокси, чтобы `/api` шёл на сервер:
```js
export default defineConfig({
  plugins: [react()],
  server: { proxy: { "/api": "http://localhost:3001" } },
});
```

## Выкладка на сервер
```bash
npm run build                 # создаст dist/
cd server && npm install --omit=dev
PORT=3001 node index.js       # сам раздаёт dist/ и /api
```
Переменные окружения: `PORT`, `DB_FILE` (путь к базе, по умолчанию `server/pokeduel.db`), `DIST_DIR`.
Держите процесс через `pm2` или `systemd`, спереди — nginx с HTTPS (Let's Encrypt).
Файл базы нужно бэкапить — там все аккаунты.

## Важно
- **HTTPS обязателен**, иначе пароли идут по сети открытым текстом.
- Пароли хранятся как scrypt-хэш с солью; токены — случайные, в базе лежит только их SHA-256.
- Результаты присылает браузер, поэтому читер может отправить фальшивую волну. Сервер отсекает невозможные значения
  (волна 1–500, побед ≤ волны) и ограничивает частоту, но полностью защититься можно только симуляцией боя на сервере.
- В `meta.js` у `defaultMeta.bp` стоит 100 «для теста» — перед выкладкой поставьте 0.
- Если список стартовиков в `STARTERS` изменится, обновите массив `STARTERS` в `server/index.js`.
